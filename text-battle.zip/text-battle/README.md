# Text Battle (FastAPI + HTMX)

A tiny, upgrade-friendly, text-based 1v1 battle game.

## Run locally
```
pip install -r requirements.txt
python run.py
```
Open http://localhost:8000
